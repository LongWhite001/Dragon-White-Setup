# Dragon-White Setup Script
# Desenvolvido por LongWhite001

function Write-Slow {
    param(
        [string]$Text,
        [int]$Delay = 100
    )
    foreach ($char in $Text.ToCharArray()) {
        Write-Host -NoNewline $char
        Start-Sleep -Milliseconds $Delay
    }
    Write-Host
}

function Show-Menu {
    Clear-Host
    Write-Host "`n== Dragon-White - Instalação de Programas =="
    Write-Host "1. Google Chrome"
    Write-Host "2. VLC Media Player"
    Write-Host "3. MPCHC (Media Player Classic Home Cinema)"
    Write-Host "4. Picasa"
    Write-Host "5. CCleaner"
    Write-Host "6. PDF Creator"
    Write-Host "7. Notepad++"
    Write-Host "8. Crystal Disk Info"
    Write-Host "9. Crystal Disk Info Shizuku"
    Write-Host "10. Crystal Disk Info Aoi"
    Write-Host "11. Navegador Brave"
    Write-Host "12. 7-Zip"
    Write-Host "13. WinRAR"
    Write-Host "14. Foxit PDF Reader"
    Write-Host "15. Instalar todos"
    Write-Host "16. Criar ícones na área de trabalho"
    Write-Host "17. Entrar no modo de reparo"
    Write-Host "0. Sair"
}

function Install-Program {
    param (
        [string]$Name,
        [string]$Url,
        [string]$Args = "/S"
    )
    Write-Host "Instalando $Name..."
    $temp = "$env:TEMP\$Name.exe"
    Invoke-WebRequest -Uri $Url -OutFile $temp
    Start-Process -Wait -FilePath $temp -ArgumentList $Args
    Remove-Item $temp
}

function Create-DesktopIcon {
    param (
        [string]$Name,
        [string]$Target,
        [string]$Icon = $null
    )
    $WshShell = New-Object -ComObject WScript.Shell
    $Desktop = [Environment]::GetFolderPath("Desktop")
    $Shortcut = $WshShell.CreateShortcut("$Desktop\$Name.lnk")
    $Shortcut.TargetPath = $Target
    if ($Icon) { $Shortcut.IconLocation = $Icon }
    $Shortcut.Save()
}

function Create-UserAndComputerIcons {
    # Meu Computador
    $Target = "::{20D04FE0-3AEA-1069-A2D8-08002B30309D}"
    Create-DesktopIcon -Name "Meu Computador" -Target $Target

    # Usuário
    $user = [System.Security.Principal.WindowsIdentity]::GetCurrent().Name.Split('\')[1]
    $UserProfile = [Environment]::GetFolderPath("UserProfile")
    Create-DesktopIcon -Name $user -Target $UserProfile
    Write-Host "Ícones criados na área de trabalho."
}

function Reparo-Menu {
    Clear-Host
    Write-Host "`n== Dragon-White - Modo de Reparo =="
    Write-Host "1. Otimizar SSD (TRIM)"
    Write-Host "2. SFC /scannow"
    Write-Host "3. CHKDSK /R /F (Requer reiniciar)"
    Write-Host "4. CHKDSK /F (Requer reiniciar)"
    Write-Host "5. Limpar arquivos temporários e lixeira"
    Write-Host "6. Listar serviços desnecessários"
    Write-Host "7. Desativar animações do Windows"
    Write-Host "0. Voltar"
}

function Otimizar-SSD {
    Write-Host "Otimização do SSD com TRIM em andamento..."
    Optimize-Volume -DriveLetter C -ReTrim -Verbose
}

function SFC-Scannow {
    Write-Host "Executando SFC /scannow..."
    sfc /scannow
}

function CHKDSK-RF {
    Write-Host "Preparando CHKDSK /R /F (pode ser agendado para o próximo boot)..."
    chkdsk C: /R /F
}

function CHKDSK-F {
    Write-Host "Preparando CHKDSK /F (pode ser agendado para o próximo boot)..."
    chkdsk C: /F
}

function Limpar-Temporarios-Lixeira {
    Write-Host "Limpando arquivos temporários e esvaziando lixeira..."
    Remove-Item -Path "$env:TEMP\*" -Recurse -Force -ErrorAction SilentlyContinue
    Clear-RecycleBin -Force -ErrorAction SilentlyContinue
}

function Listar-Servicos-Desnecessarios {
    Write-Host "Listando serviços desnecessários (manual e desativados recomendados):"
    $servicos = Get-Service | Where-Object { $_.Status -eq "Running" }
    # Apenas exemplos de serviços comuns para desativar, ajuste conforme necessário
    $lista = @(
        "Fax", "XblGameSave", "MapsBroker", "RetailDemo", "WMPNetworkSvc", "DiagTrack", "WerSvc"
    )
    $filtrados = $servicos | Where-Object { $lista -contains $_.Name }
    if ($filtrados.Count -eq 0) {
        Write-Host "Nenhum serviço potencialmente desnecessário está ativo."
    } else {
        $i = 1
        foreach ($svc in $filtrados) {
            Write-Host "$i. $($svc.Name) - $($svc.DisplayName)"
            $i++
        }
        $opt = Read-Host "Digite o número do serviço que deseja desativar (ou ENTER para pular)"
        if ($opt -match '^\d+$' -and ($opt -le $filtrados.Count)) {
            $svc = $filtrados[$opt-1]
            Stop-Service -Name $svc.Name -Force
            Set-Service -Name $svc.Name -StartupType Disabled
            Write-Host "Serviço $($svc.Name) desativado."
        }
    }
}

function Desativar-Animacoes {
    Write-Host "Desativando animações do Windows..."
    Set-ItemProperty "HKCU:\Control Panel\Desktop\WindowMetrics" -Name MinAnimate -Value 0
    Set-ItemProperty "HKCU:\Software\Microsoft\Windows\CurrentVersion\Explorer\VisualEffects" -Name VisualFXSetting -Value 2
    Write-Host "Animações desativadas."
}

function Show-DragonArt {
@"
                   ___====-_  _-====___
             _--^^^#####//      \\#####^^^--_
          _-^##########// (    ) \\##########^-_
         -############//  |\^^/|  \\############-
       _/############//   (@::@)   \\############\_
      /#############((     \\//     ))#############\
     -###############\\    (oo)    //###############-
    -#################\\  / "" \  //#################-
   -###################\\/  (_)  \//###################-
  _#/|##########/\######(   "/"   )######/\##########|\#_
  |/ |#/\#/\#/\/  \#/\##\  ! ' !  /##/\#/  \/\#/\#/\#| \|
  '  |/  V  V '   V  \\#\   . .   /#/  V   '  V  V  \|  '
     '   '  '      '   / |  . .  | \   '      '  '   '
                      (  |  . .  |  )
                     __\ |  . .  | /__
                    (vvv(VVV)(VVV)vvv)
"@
    Write-Host ""
    Write-Host "         Dragon-White" -ForegroundColor Red
    Write-Host ""
    Write-Host "Pressione qualquer tecla para sair..."
    $null = $Host.UI.RawUI.ReadKey("NoEcho,IncludeKeyDown")
}

# Links diretos de instaladores silenciosos
$Programas = @{
    "Google Chrome" = @{ Url = "https://dl.google.com/chrome/install/latest/chrome_installer.exe"; Args = "/silent /install" }
    "VLC Media Player" = @{ Url = "https://get.videolan.org/vlc/last/win64/vlc-3.0.20-win64.exe"; Args = "/S" }
    "MPCHC" = @{ Url = "https://github.com/clsid2/mpc-hc/releases/download/1.9.24/MPC-HC.1.9.24.x64.exe"; Args = "/verysilent" }
    "Picasa" = @{ Url = "https://d3f0a05xgmyh48.cloudfront.net/Picasa39-setup.exe"; Args = "/S" }
    "CCleaner" = @{ Url = "https://download.ccleaner.com/ccsetup.exe"; Args = "/S" }
    "PDF Creator" = @{ Url = "https://download.pdfforge.org/pdfcreator/PDFCreator-stable.exe"; Args = "/VERYSILENT" }
    "Notepad++" = @{ Url = "https://github.com/notepad-plus-plus/notepad-plus-plus/releases/download/v8.6.8/npp.8.6.8.Installer.x64.exe"; Args = "/S" }
    "Crystal Disk Info" = @{ Url = "https://osdn.net/projects/crystaldiskinfo/downloads/78727/CrystalDiskInfo8_17_14.exe"; Args = "/S" }
    "Crystal Disk Info Shizuku" = @{ Url = "https://osdn.net/projects/crystaldiskinfo/downloads/78729/CrystalDiskInfo8_17_14Shizuku.exe"; Args = "/S" }
    "Crystal Disk Info Aoi" = @{ Url = "https://osdn.net/projects/crystaldiskinfo/downloads/78731/CrystalDiskInfo8_17_14Aoi.exe"; Args = "/S" }
    "Navegador Brave" = @{ Url = "https://laptop-updates.brave.com/latest/winx64"; Args = "/silent" }
    "7-Zip" = @{ Url = "https://www.7-zip.org/a/7z2405-x64.exe"; Args = "/S" }
    "WinRAR" = @{ Url = "https://www.rarlab.com/rar/winrar-x64-624.exe"; Args = "/S" }
    "Foxit PDF Reader" = @{ Url = "https://cdn01.foxitsoftware.com/pub/foxit/reader/desktop/win/12.x/12.1.3.15356/FoxitPDFReader1213_L10N_Setup.exe"; Args = "/silent" }
}

# Início do script
Clear-Host
Write-Slow "Dragon-White" 200

do {
    Show-Menu
    $opcao = Read-Host "`nEscolha uma opção"
    switch ($opcao) {
        "1" { Install-Program "Google Chrome" $Programas["Google Chrome"].Url $Programas["Google Chrome"].Args }
        "2" { Install-Program "VLC Media Player" $Programas["VLC Media Player"].Url $Programas["VLC Media Player"].Args }
        "3" { Install-Program "MPCHC" $Programas["MPCHC"].Url $Programas["MPCHC"].Args }
        "4" { Install-Program "Picasa" $Programas["Picasa"].Url $Programas["Picasa"].Args }
        "5" { Install-Program "CCleaner" $Programas["CCleaner"].Url $Programas["CCleaner"].Args }
        "6" { Install-Program "PDF Creator" $Programas["PDF Creator"].Url $Programas["PDF Creator"].Args }
        "7" { Install-Program "Notepad++" $Programas["Notepad++"].Url $Programas["Notepad++"].Args }
        "8" { Install-Program "Crystal Disk Info" $Programas["Crystal Disk Info"].Url $Programas["Crystal Disk Info"].Args }
        "9" { Install-Program "Crystal Disk Info Shizuku" $Programas["Crystal Disk Info Shizuku"].Url $Programas["Crystal Disk Info Shizuku"].Args }
        "10" { Install-Program "Crystal Disk Info Aoi" $Programas["Crystal Disk Info Aoi"].Url $Programas["Crystal Disk Info Aoi"].Args }
        "11" { Install-Program "Navegador Brave" $Programas["Navegador Brave"].Url $Programas["Navegador Brave"].Args }
        "12" { Install-Program "7-Zip" $Programas["7-Zip"].Url $Programas["7-Zip"].Args }
        "13" { Install-Program "WinRAR" $Programas["WinRAR"].Url $Programas["WinRAR"].Args }
        "14" { Install-Program "Foxit PDF Reader" $Programas["Foxit PDF Reader"].Url $Programas["Foxit PDF Reader"].Args }
        "15" {
            foreach ($prog in $Programas.Keys) {
                Install-Program $prog $Programas[$prog].Url $Programas[$prog].Args
            }
        }
        "16" { Create-UserAndComputerIcons }
        "17" {
            do {
                Reparo-Menu
                $reparo = Read-Host "`nEscolha uma opção de reparo"
                switch ($reparo) {
                    "1" { Otimizar-SSD }
                    "2" { SFC-Scannow }
                    "3" { CHKDSK-RF }
                    "4" { CHKDSK-F }
                    "5" { Limpar-Temporarios-Lixeira }
                    "6" { Listar-Servicos-Desnecessarios }
                    "7" { Desativar-Animacoes }
                }
                if ($reparo -ne "0") { Pause }
            } while ($reparo -ne "0")
        }
    }
} while ($opcao -ne "0")

Show-DragonArt